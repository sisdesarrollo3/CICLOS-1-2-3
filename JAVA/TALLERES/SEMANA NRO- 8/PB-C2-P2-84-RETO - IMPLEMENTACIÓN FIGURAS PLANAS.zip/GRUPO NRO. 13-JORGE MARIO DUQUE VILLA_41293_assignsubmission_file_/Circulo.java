package Clases;


public class Circulo extends FigurasPlanas{
    private double radio;
    private double diametro;
    
    
    ///constructor
    public Circulo(double radio,String nombre,double area,double perimetro) {
        super(nombre,perimetro,area);
        this.radio=radio;
        
      
        
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

   
    public double  calcularArea()
    {
      return (3.1416*(radio*radio) );
    }
    public double calcularPerimetro(){
      return (2*3.1416*radio);
    }
    public double calculardiametro(){
      return (radio*2);
    } 
    
   
    
}
