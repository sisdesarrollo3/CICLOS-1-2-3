////JORGE MARIO DUQUE VILLA Y RONNY TETE
package proyectomario;
import Clases.Cuadrado;
import Clases.Rectangulo;
import Clases.Triangulo;
import Clases.Circulo;
import java.util.Scanner;


public class ProyectoMario {
    int medida = 77;
    public static void main(String[] args) {
        
       Scanner teclado = new Scanner(System.in);
       char opcion = '3';
       do{
         menu();
         opcion = teclado.nextLine().charAt(0);
         switch (opcion){
             case '1': construirRectangulos(teclado); break;
             case '2': construirCuadrados(teclado);   break;
             case '3': construirTriangulos(teclado);  break;
             case '4': construirCirculos(teclado);    break;
             case '5': System.out.println("salio del sistema muchas gracias");
             default:  System.out.println("OPCION NO VALIDA");
         }
       }
       while(opcion != '5');
       
    }
    
    public static void construirRectangulos(Scanner teclado){
      System.out.println("NOMBRE: ");
     String nombre = teclado.nextLine();
      double area=0;
      double perimetro=0;
      System.out.println("LADO1: ");double lado1 = teclado.nextDouble();
      System.out.println("LADO2: ");double lado2 = teclado.nextDouble();
      Rectangulo myRectangulo = new Rectangulo( lado1, lado2,nombre, perimetro,area);
      
      System.out.println("se trae el NOMBRE: " + myRectangulo.getNombre());
      System.out.println("se trae el AREA: " + myRectangulo.calcularArea());
      System.out.println("se trae el PERIMETRO: " + myRectangulo.calcularPerimetro());
      
    }
    public static void construirCuadrados(Scanner teclado){
      System.out.println("NOMBRE: ");
     String nombre = teclado.nextLine();
      double area=0;
      double perimetro=0;
      System.out.println("LADO1: ");double lado1 = teclado.nextDouble();
      System.out.println("LADO2: ");double lado2 = teclado.nextDouble();
      Cuadrado myCuadrado = new Cuadrado( lado1, lado2,nombre, perimetro,area);
      
      System.out.println("se trae el NOMBRE: " + myCuadrado.getNombre());
      System.out.println("se trae el AREA: " + myCuadrado.calcularArea());
      System.out.println("se trae el PERIMETRO: " + myCuadrado.calcularPerimetro());
      
    }
    public static void construirTriangulos(Scanner teclado){
      System.out.println("escojiste triangulo");
      
      System.out.println("NOMBRE: ");String nombre = teclado.nextLine();
      System.out.println("ALTURA: ");double altura = teclado.nextDouble();
      System.out.println("BASE: ");double base = teclado.nextDouble();
      System.out.println("LADO1: ");double lado1 = teclado.nextDouble();
      System.out.println("LADO2: ");double lado2 = teclado.nextDouble();
      double area=0;
      double perimetro=0;
      Triangulo myTriangulo = new Triangulo(base,altura, lado1, lado2,nombre, perimetro,area);
      
      System.out.println("se trae el NOMBRE: " + myTriangulo.getNombre());
      System.out.println("se trae el AREA: " + myTriangulo.calcularArea());
      System.out.println("se trae el PERIMETRO: " + myTriangulo.calcularPerimetro());
      System.out.println("BASE=");
      System.out.println(base);
      System.out.println("ALTURA=");
      System.out.println(altura);
    }
    
     public static void construirCirculos(Scanner teclado){
      System.out.println("escojiste circulo");
      
      System.out.println("NOMBRE: ");String nombre = teclado.nextLine();
      System.out.println("RADIO: ");double radio = teclado.nextDouble();
     
     
      double area=0;
      double perimetro=0;
      Circulo myCirculo = new Circulo(radio,nombre, perimetro,area);
      
      System.out.println("se trae el NOMBRE: " + myCirculo.getNombre());
      System.out.println("se trae el AREA: " + myCirculo.calcularArea());
      System.out.println("se trae el PERIMETRO: " + myCirculo.calcularPerimetro());
      System.out.println("diametro=");
      System.out.println("se trae el DIAMETRO: " + myCirculo.calculardiametro());
      System.out.println("radio=");
      System.out.println(radio);
    }
    
    public static void menu(){
      System.out.println("*** MENU ***");
      System.out.println("*** JORGE MARIO DUQUE VILLA ***");
      System.out.println("[1] Rectangulos");
      System.out.println("[2] Cuadrados");
      System.out.println("[3] Triangulos");
      System.out.println("[4] Circulos");
      System.out.println("[5] Salir");
      System.out.print("OPCION=");
    }
    
}
