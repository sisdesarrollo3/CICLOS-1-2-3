package Clases;



public class Rectangulo extends Figuras {
 
	//Atributos 
	private double base;
	private double altura;
 
	
	public Rectangulo(double base, double altura) {
		this.base = base;
		this.altura = altura;
		calcularArea();
		calcularPerimetro();
	}
 
	
	@Override
	protected void calcularArea() {
		area = base * altura;
	}
 
	@Override
	protected void calcularPerimetro() {
		perimetro = (2*base) + (2*altura);
	}

    @Override
    public void mostrarDatos() {
        
                System.out.println("***MOSTRANDO DATOS DEL RECTANGULO***");
                System.out.println("====================================");
                System.out.println("Base : " + this.base);
                System.out.println("Altura :" + this.altura);
                System.out.println("Perimetro :" + this.perimetro);
                System.out.println("Area :" + this.area);
    
    }
    
 
}
