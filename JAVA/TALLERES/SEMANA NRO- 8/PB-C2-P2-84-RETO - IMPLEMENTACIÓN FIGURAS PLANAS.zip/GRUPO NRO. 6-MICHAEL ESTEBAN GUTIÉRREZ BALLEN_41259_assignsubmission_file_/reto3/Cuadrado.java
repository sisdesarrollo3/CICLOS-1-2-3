package Clases;



public class Cuadrado extends Figuras {
 
	//Atributos 
	private double base;
	private double altura;
 
	
	public Cuadrado (double base, double altura) {
		this.base = base;
		this.altura = altura;
		calcularArea();
		calcularPerimetro();
	}
 
	
	@Override
	protected void calcularArea() {
		area = base * altura;
	}
 
	@Override
	protected void calcularPerimetro() {
		perimetro = 4*base;
	}

    @Override
    public void mostrarDatos() {
        
                System.out.println("***MOSTRANDO DATOS DEL CUADRADO***");
                System.out.println("==================================");
                System.out.println("Base : " + this.base);
                System.out.println("Altura :" + this.altura);
                System.out.println("Perimetro :" + this.perimetro);
                System.out.println("Area :" + this.area);
    
    }
    
 
}

