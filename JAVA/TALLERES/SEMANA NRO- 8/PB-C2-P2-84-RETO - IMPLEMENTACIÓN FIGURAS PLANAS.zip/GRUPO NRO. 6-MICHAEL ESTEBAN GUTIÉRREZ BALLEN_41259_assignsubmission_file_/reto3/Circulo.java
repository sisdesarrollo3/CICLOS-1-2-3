package Clases;



public class Circulo extends Figuras {
 
	private double radio;
        
 
	public Circulo(double radio) {
		this.radio = radio;
		calcularArea();
		calcularPerimetro();
	}
 
	@Override
	protected void calcularArea() {
		area = Math.PI * Math.pow(radio, 2);
	}
 
	@Override
	protected void calcularPerimetro() {
		perimetro = 2 * Math.PI * radio;
	}
        
        @Override
        public void mostrarDatos(){
                System.out.println("***MOSTRANDO DATOS DEL CIRCULO");
                System.out.println("===============================");
                System.out.println("Radio :" + this.radio);
                System.out.println("Perimetro :" + this.perimetro);
                System.out.println("Area :" + this.area);
        }
        
         
        
 
}
