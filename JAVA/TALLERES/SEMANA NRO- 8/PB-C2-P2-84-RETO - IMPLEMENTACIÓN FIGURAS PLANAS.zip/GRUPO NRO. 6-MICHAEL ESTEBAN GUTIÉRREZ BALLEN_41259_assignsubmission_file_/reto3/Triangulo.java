package Clases;



public class Triangulo extends Figuras {
 
	private double base;
	private double altura;
	private double lado1;
	private double lado2;
	private double lado3;
        
 
	public Triangulo(double base, double altura, double lado1, double lado2, double lado3) {
		this.base = base;
		this.altura = altura;
		this.lado1 = lado1;
		this.lado2 = lado2;
		this.lado3 = lado3;
		calcularArea();
		calcularPerimetro();
	}
 
	@Override
	protected void calcularArea() {
		area = base * altura / 2;
	}
 
	@Override
	protected void calcularPerimetro() {
		perimetro = lado1 + lado2 + lado3;
	}

    @Override
    public void mostrarDatos() {
       
                System.out.println("***MOSTRANDO DATOS DEL TRIANGULO");
                System.out.println("=================================");
                System.out.println("Base : " + this.base);
                System.out.println("Altura :" + this.altura);
                System.out.println("Lado 1 :" + this.lado1);
                System.out.println("Lado 2 :" + this.lado2);
                System.out.println("Lado 3 :" + this.lado3);   
                System.out.println("Perimetro :" + this.perimetro);
                System.out.println("Area :" + this.area);
    
    
    }
 
}