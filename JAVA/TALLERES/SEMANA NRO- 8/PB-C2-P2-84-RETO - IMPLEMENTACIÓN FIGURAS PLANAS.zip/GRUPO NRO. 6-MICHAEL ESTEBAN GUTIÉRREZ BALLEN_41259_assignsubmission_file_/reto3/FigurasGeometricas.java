package figurasgeometricas;

import Clases.Circulo;
import Clases.Figuras;
import Clases.Rectangulo;
import Clases.Triangulo;
import Clases.Cuadrado;
import java.util.Scanner;



public abstract class FigurasGeometricas {
 
    public static void main(String[] args) {
      /* Figuras circulo = new Circulo (8);
       
        System.out.println(circulo.());
        System.out.println(circulo.getPerimetro());
        
        Figuras triangulo = new Triangulo (3,5,3,3,3);
        
        System.out.println(triangulo.getArea());
        System.out.println(triangulo.getPerimetro());
        
        Figuras rectangulo = new Rectangulo (6,4);
        
        System.out.println(rectangulo.getArea());
        System.out.println(rectangulo.getPerimetro());
        
    */    
      Scanner teclado = new Scanner (System.in);  
        System.out.println(  "* * * * RETO N° 3 * * * *");
        System.out.println("APLICANDO PROGRAMACION A OBJETOS");
        System.out.println("=================================");
        System.out.println("[1].--> Construir un Rectangulo ");
        System.out.println("[2].--> Construir un Tiangulo ");
        System.out.println("[3].--> Construir un Circulo ");
        System.out.println("[4].--> Construir un Cuadrado");
        System.out.println("[5].--> Salir ");
        int opcion = teclado.nextInt();
        System.out.println("Opcion : "+ opcion);
        
        switch(opcion){
            case 1 : 
                System.out.println("Ingrese la base :");
                double datoRectangulob = teclado.nextDouble();
                System.out.println("Ingrese la altura :");
                double datoRectanguloA = teclado.nextDouble();
                Figuras rectangulo = new Rectangulo (datoRectangulob,datoRectanguloA);
                rectangulo.mostrarDatos();
                break;
                
            case 2 : 
                System.out.println("Ingrese la base :");
                double datoTriangulob = teclado.nextDouble();
                System.out.println("Ingrese la altura :");
                double datoTrianguloa = teclado.nextDouble();
                System.out.println("Ingrese el lado 1 :");
                double datoTrlado1 = teclado.nextDouble();
                System.out.println("Ingrese el lado 2 :");
                double datoTrlado2 = teclado.nextDouble();
                System.out.println("Ingrese el lado 3 :");
                double datoTrlado3 = teclado.nextDouble();
                Figuras triangulo = new Triangulo (datoTriangulob,datoTrianguloa,
                        datoTrlado1,datoTrlado2,datoTrlado3);
                triangulo.mostrarDatos();
                break;
                
            case 3 :
                System.out.println("Ingrese el valor del Radio : ");
                double dato = teclado.nextDouble();
                Figuras circulo = new Circulo (dato);   
                circulo.mostrarDatos();
                break;
            
            case 4 :
                System.out.println("Ingrese la base :");
                double datoCuadradob = teclado.nextDouble();
                System.out.println("Ingrese la altura :");
                double datoCuadradoA = teclado.nextDouble();
                Figuras cuadrado = new Cuadrado (datoCuadradob,datoCuadradoA);
                cuadrado.mostrarDatos();
                break;
                
            case 5 : 
                System.out.println("Saliendo del programa");
                break;
        }
    }
    
   
	
}


 
	