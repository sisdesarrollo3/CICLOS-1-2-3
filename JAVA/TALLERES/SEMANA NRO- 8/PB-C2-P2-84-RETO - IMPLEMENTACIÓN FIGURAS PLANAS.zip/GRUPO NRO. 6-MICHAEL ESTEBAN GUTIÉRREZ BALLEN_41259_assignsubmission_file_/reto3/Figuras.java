package Clases;



public abstract class Figuras {
 
	//Atributos comunes a todas las figuras
	protected double area;
	protected double perimetro;
        
 
	//Métodos get
	public double getArea() {
		return area;
	}
 
	public double getPerimetro() {
		return perimetro;
	}
        
       
	
	protected abstract void calcularArea();
 
	protected abstract void calcularPerimetro();
        
        public abstract void mostrarDatos ();
 
}


 
	